from distutils.core import setup
setup(
name = 'nested',
version = '1.0.0',
py_modules = ['nested'],
author = 'DerekReilly',
author_email = 'derekr31@hotmail.com',
description = 'A simple printer of nested lists',
)