from distutils.core import setup
setup(
name = 'nested',
version = '1.4.0',
py_modules = ['nested'],
author = 'DerekReilly',
author_email = 'derekr31@hotmail.com',
url = 'https://www.facebook.com/derek.reilly.96',
description = 'A simple printer of nested lists',
)